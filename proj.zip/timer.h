#pragma once
#include <lcom/lcf.h>

int(timer_subscribe_int)(uint8_t *bit_no);
int(timer_unsubscribe_int)();
