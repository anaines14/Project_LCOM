#pragma once
#include <lcom/lcf.h>
#include <lcom/liblm.h>

int (game_start)();
int (interrupts)();

