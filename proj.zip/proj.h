#pragma once
#include <lcom/lcf.h>
#include <lcom/liblm.h>
#include <lcom/proj.h>

#include <stdbool.h>
#include <stdint.h>
#include "mainLoop.h"
int(proj_main_loop)(int argc, char *argv[]);
