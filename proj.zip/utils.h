#pragma once
#include <lcom/lcf.h>

int (util_sys_inb)(int port, uint8_t *value);
